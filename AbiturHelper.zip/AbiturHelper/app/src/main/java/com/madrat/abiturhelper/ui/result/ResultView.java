package com.madrat.abiturhelper.ui.result;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.madrat.abiturhelper.R;

public class ResultView extends Fragment {
    private TextView tv;
    private int maths, russian;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        tv.setText("Общая сумма баллов = " + String.valueOf(russian + maths));

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_result, container, false);
        tv = view.findViewById(R.id.result);



        russian = getArguments().getInt("editTextRussian");
        maths = getArguments().getInt("editTextMaths");
        return view;
    }
}
