package com.madrat.abiturhelper.ui.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;

public interface ActivityVP {
    interface View {
        void setUp(Bundle savedInstanceState);
        void setFragment(Fragment fragment, Bundle savedInstanceState);
    }

    interface Presenter {
        void addFragment(Fragment fragment, Bundle savedInstanceState);
    }

    interface Repository {

    }
}
