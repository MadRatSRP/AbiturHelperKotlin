package com.madrat.abiturhelper.ui.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;

import com.madrat.abiturhelper.R;
import com.madrat.abiturhelper.ui.ege.EgeView;

public class Activity extends AppCompatActivity
    implements ActivityVP.View{

    private FragmentManager fm;
    private FragmentTransaction ft;
    private ActivityPresenter activityPresenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);
        setUp(savedInstanceState);
    }

    @Override
    public void setUp(Bundle savedInstanceState) {
        activityPresenter = new ActivityPresenter(this);
        activityPresenter.addFragment(new EgeView(), savedInstanceState);
    }

    @Override
    public void setFragment(Fragment fragment, Bundle savedInstanceState) {
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, fragment).commit();
        }
    }
}