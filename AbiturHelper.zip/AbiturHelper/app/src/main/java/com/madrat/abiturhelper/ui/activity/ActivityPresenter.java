package com.madrat.abiturhelper.ui.activity;

import android.os.Bundle;
import android.support.v4.app.Fragment;

public class ActivityPresenter
    implements ActivityVP.Presenter{

    ActivityVP.View avi;
    private String TAG = "ActivityPresenter";

    public ActivityPresenter(ActivityVP.View avi) {
        this.avi = avi;
    }

    @Override
    public void addFragment(Fragment fragment, Bundle savedInstanceState) {
        avi.setFragment(fragment, savedInstanceState);
    }


}
