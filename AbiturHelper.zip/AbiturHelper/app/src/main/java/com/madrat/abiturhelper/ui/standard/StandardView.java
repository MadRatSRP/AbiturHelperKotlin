package com.madrat.abiturhelper.ui.standard;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.madrat.abiturhelper.R;
import com.madrat.abiturhelper.ui.ege.EgeView;
import com.madrat.abiturhelper.ui.result.ResultView;

public class StandardView extends Fragment {
    private Button buttonConfirm, buttonEge;
    private EditText editTextMaths, editTextRussian;
    EditText ed;
    LinearLayout layout;
    Spinner spinner;

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        EgeView egeView = new EgeView();
        buttonEge.setOnClickListener((View view) -> {
            //getFragmentManager().beginTransaction().add(R.id.ege_container, egeView).commit();

            /*for (int i = 0; i < 5; i++) {

                ed = new EditText(getActivity().getApplicationContext());
                //ed.setBackgroundResource(R.color.blackOpacity);
                ed.setId(i);
                ed.setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT));
                layout.addView(ed);

            }*/

            spinner = new Spinner(getActivity().getApplicationContext());
            spinner.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            // Add Spinner to LinearLayout
            if (layout != null) {
                layout.addView(spinner);
            }

        });

        buttonConfirm.setOnClickListener((View view) -> {
            ResultView resultView = new ResultView();
            Bundle args = new Bundle();
            //загружаем значения полей в Bundle
            args.putInt("editTextMaths", Integer.parseInt(editTextMaths.getText().toString()));
            args.putInt("editTextRussian", Integer.parseInt(editTextRussian.getText().toString()));
            resultView.setArguments(args);
            //Меняем фрагмент с полями ввода на фрагмент с результатами действий
            getFragmentManager().beginTransaction().replace(R.id.container, resultView).commit();
        });
    }

    private TextWatcher loginTextWatcher = new TextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

        }

        @Override
        public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            String mathsInput = editTextMaths.getText().toString();
            String russianInput = editTextRussian.getText().toString();
            //Делаем кнопку активной только тогда, когда оба поля не пусты.
            buttonConfirm.setEnabled(!mathsInput.isEmpty() && !russianInput.isEmpty());
        }

        @Override
        public void afterTextChanged(Editable editable) {

        }
    };

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_standard, container, false);
        buttonConfirm = view.findViewById(R.id.submit);
        buttonEge = view.findViewById(R.id.button_ege);
        layout = view.findViewById(R.id.ll);

        editTextMaths = view.findViewById(R.id.maths);
        editTextRussian = view.findViewById(R.id.russian);
        editTextMaths.addTextChangedListener(loginTextWatcher);
        editTextRussian.addTextChangedListener(loginTextWatcher);
        return view;
    }

    public static Fragment newInstance()
    {
        StandardView standardView = new StandardView();
        return standardView;
    }
}
